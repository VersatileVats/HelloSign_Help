<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="https://cdn.hellosign.com/public/js/embedded/v2.10.0/embedded.development.js"></script>
    <title>Document</title>
</head>
<body>
    <h1>Hello I am here</h1>

    <?php
        require_once 'vendor/autoload.php';
        $client = new HelloSign\Client('API_KEY');
        $request = new HelloSign\SignatureRequest;
        $request->enableTestMode();
        $request->setSubject('Signing Request Alert - Intimation Required');
        $request->setMessage('Almost there');
        $request->addSigner('lalita1979.vats@gmail.com', 'Harshika');
        $request->addFile('sample.pdf');

        $client_id = '502db432648a8958e9b35e7f26603dc2';
        $embedded_request = new HelloSign\EmbeddedSignatureRequest($request, $client_id);
        $response = $client->createEmbeddedSignatureRequest($embedded_request);

        echo("The signature request is: ");print_r($response->signatures[0]->signature_id);

        $response1 = $client->getEmbeddedSignUrl($response->signatures[0]->signature_id);
        echo '<br>'; echo("Sign_url is: ");echo '<br>';print_r($response1->sign_url);
?>
</body>

<script>
    const client = new HelloSign({
        clientId: '502db432648a8958e9b35e7f26603dc2'
    });

    client.open('<?php echo($response1->sign_url) ?>', {
        skipDomainVerification: true,
        debug: true
    });
</script>
</html>