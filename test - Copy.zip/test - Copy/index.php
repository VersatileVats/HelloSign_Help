<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="https://cdn.hellosign.com/public/js/embedded/v2.10.0/embedded.development.js"></script>
    <title>Document</title>
</head>
<body>
<?php
    require_once 'vendor/autoload.php';
    
    $client = new HelloSign\Client('API_KEY');
    $client_id = '502db432648a8958e9b35e7f26603dc2';

    $request = new HelloSign\Template();
    $request->enableTestMode();
    $request->setClientId($client_id);
    $request->addFile('sample.pdf');
    $request->setTitle('Test Title');
    $request->setSubject('Approval Consent');
    $request->setMessage('Fill this as soon as possible');
    $request->addSignerRole('Hospital', 1);
    $request->addMergeField('Vishal Vats', 'text');
    $request->addMergeField('allaboutclashing@gmail.com', 'text');

    $response = $client->createEmbeddedDraft($request);

    $new_template_id = $response->getId();
    $edit_url = $response->getEditUrl();
    $is_embedded_draft = $response->isEmbeddedDraft();

    echo('Template id is: ');print_r($new_template_id);echo "<br>";
    echo('Edit url is: ');print_r($edit_url);echo "<br>";
    echo('Embedded Draft is: ');print_r($is_embedded_draft);echo "<br>";

?>
<h2>Creating a new draft template</h2>
<a href='signReq.php?tid=<?php print_r($new_template_id) ?>' target='_blank'>Click Here</a>

</body>
<script>
    const client = new HelloSign({
        clientId: '502db432648a8958e9b35e7f26603dc2'
    });

    client.open('<?php echo($edit_url) ?>', {
        skipDomainVerification: true
        // debug: true
    });

    client.on('createTemplate', (data) => {
        console.log('createTemplate');
        console.log('Response ' + JSON.stringify(data));
    });

    client.on('open', (data) => {
        console.log('open');
        console.log('Response ' + JSON.stringify(data));
    });

    client.on('cancel', (data) => {
        console.log('cancel');
        console.log('Response ' + JSON.stringify(data));
    });

    client.on('finish', (data) => {
        console.log('finish');
        console.log('Response ' + JSON.stringify(data));
    });

    client.on('message', (data) => {
        console.log('message');
        console.log('Response ' + JSON.stringify(data));
    });

    client.on('close', (data) => {
        console.log('close');
        console.log('Response ' + JSON.stringify(data));
    });

    client.on('error', (data) => {
        console.log('error');
        console.log('Response ' + JSON.stringify(data));
    });
</script>
</html>