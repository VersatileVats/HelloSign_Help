<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="https://cdn.hellosign.com/public/js/embedded/v2.10.0/embedded.development.js"></script>
    <title>Document</title>
</head>
<body>
<?php
    require_once 'vendor/autoload.php';
    $templateId = $_GET['tid'];

    $client = new HelloSign\Client('API_KEY');
    $client_id = '502db432648a8958e9b35e7f26603dc2';

    $baseReq = new HelloSign\TemplateSignatureRequest();
    $baseReq->enableTestMode();
    $baseReq->setTemplateId($templateId);
    $baseReq->setSubject('Attention Required');
    $baseReq->setMessage('Hooray');
    $baseReq->setSigner('Hospital', 'harshika1406.vats@gmail.com', 'Harshika');
    $baseReq->setSigningRedirectUrl('https://versatilevats.tech/w4w');
    $baseReq->setRequestingRedirectUrl('https://versatilevats.tech/w4w');
    $baseReq->setRequesterEmailAddress('vishalvats2000@gmail.com');

    $request = new HelloSign\EmbeddedSignatureRequest($baseReq);
    $request->setClientId($client_id);
    $request->setEmbeddedSigning();

    $response = $client->createUnclaimedDraftEmbeddedWithTemplate($request);
    echo('Here are the details: '); print_r($response->claim_url);

?>
<h3>Embedded Signing Request</h3>

</body>

<script>
    const client = new HelloSign({
        clientId: '502db432648a8958e9b35e7f26603dc2'
    });

    client.open('<?php echo($response->claim_url) ?>', {
        skipDomainVerification: true
    });
</script>

</html>